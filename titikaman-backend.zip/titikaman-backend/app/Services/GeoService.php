<?php
namespace App\Services;
class GeoService {
    public static function distanceM(float $lat1, float $lng1, float $lat2, float $lng2): float {
        $r = 6371000; $dLat = deg2rad($lat2-$lat1); $dLng = deg2rad($lng2-$lng1);
        $a = sin($dLat/2)**2 + cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLng/2)**2;
        return $r * 2 * atan2(sqrt($a), sqrt(1-$a));
    }
    public static function inBbox(float $lat, float $lng, array $box): bool {
        return $lat >= $box['min_lat'] && $lat <= $box['max_lat'] && $lng >= $box['min_lng'] && $lng <= $box['max_lng'];
    }
    public static function regionForPoint(float $lat, float $lng): ?string {
        foreach (config('titikaman.regions') as $slug => $r) {
            if (self::inBbox($lat, $lng, $r)) return $slug;
        }
        return null;
    }
    public static function minDistanceToPolyline(float $lat, float $lng, array $coords): float {
        $min = PHP_FLOAT_MAX;
        foreach ($coords as $c) {
            $d = self::distanceM($lat, $lng, $c[1], $c[0]);
            if ($d < $min) $min = $d;
        }
        return $min === PHP_FLOAT_MAX ? 999999 : $min;
    }
}
