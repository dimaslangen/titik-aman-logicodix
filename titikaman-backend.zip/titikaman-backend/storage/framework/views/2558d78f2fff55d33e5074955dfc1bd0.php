<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TitikAman — Halaman Tes API (Leaflet)</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>body{font-family:system-ui,sans-serif;margin:0;background:#0f172a;color:#e2e8f0}header{padding:12px 16px;background:#162a4b}h1{margin:0;font-size:18px}#map{height:52vh;width:100%}.wrap{padding:12px 16px;display:grid;gap:12px;grid-template-columns:1fr 1fr} @media(max-width:700px){.wrap{grid-template-columns:1fr}} .card{background:#1e293b;border-radius:10px;padding:12px} label{display:block;font-size:12px;margin:6px 0 2px} input,select,textarea{width:100%;padding:8px;border-radius:6px;border:1px solid #475569;background:#0f172a;color:#fff} button{background:#2eb5a6;color:#06281f;border:0;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;margin-top:8px} pre{background:#020617;padding:10px;border-radius:8px;overflow:auto;max-height:300px;font-size:12px} .warn{color:#fbbf24;font-size:13px} a{color:#5eead4}</style></head>
<body><header><h1>TitikAman — Halaman Tes API (bukan UI final)</h1><p style="margin:4px 0 0;font-size:13px">Backend Laravel 13 + MySQL. Halaman ini cuma buat nyoba API. UI final dibuat Amy. Disclaimer: SafePass alat bantu komunitas, bukan jaminan keselamatan absolut — darurat hubungi 110.</p></header>
<div id="map"></div>
<div class="wrap">
<div class="card"><h3>1. Rute: Tercepat vs SafePass</h3>
<label>Region</label><select id="region"><option value="rawamangun">Rawamangun</option><option value="unesa-lidah-wetan">UNESA Lidah Wetan</option><option value="unesa-ketintang">UNESA Ketintang</option></select>
<label>Moda</label><select id="mode"><option value="motor">Motor</option><option value="mobil">Mobil</option><option value="jalan_kaki">Jalan Kaki</option></select>
<label>Asal (lat,lng)</label><input id="o" value="-6.1955,106.9005">
<label>Tujuan (lat,lng)</label><input id="d" value="-6.1900,106.8940">
<button onclick="loadRoutes()">Bandingkan Rute</button>
<button onclick="loadData()">Muat Hub + Laporan</button>
<div id="routeInfo" style="font-size:13px;margin-top:8px"></div></div>
<div class="card"><h3>2. Login &amp; Lapor (login wajib)</h3>
<label>Email</label><input id="email" value="warga@titikaman.id"><label>Password</label><input id="pass" type="password" value="Warga123!">
<button onclick="login()">Login</button> <span id="who" style="font-size:12px"></span>
<label>Kategori</label><select id="cat"><option value="penerangan_padam">Penerangan Padam</option><option value="area_sepi">Area Sepi</option><option value="hambatan_fisik">Hambatan Fisik</option></select>
<label>Titik laporan (lat,lng) — harus ≤20 m dari posisi Anda</label><input id="rloc" value="-6.1935,106.8985">
<label>Posisi Anda (lat,lng)</label><input id="uloc" value="-6.1935,106.8985">
<label>Deskripsi</label><input id="desc" value="Tes laporan dari halaman test">
<button onclick="lapor()">Kirim Laporan</button>
<button onclick="sos()">SOS (catat alert + tel:110)</button>
<div class="warn">Mode Simulasi: <span id="sim">?</span> — aktifkan via admin kalau mau lapor dari mana saja (demo juri).</div></div>
</div>
<div class="wrap"><div class="card"><h3>Response JSON</h3><pre id="out">Belum ada request. Klik tombol di atas.</pre></div>
<div class="card"><h3>Endpoint cepat</h3><p style="font-size:13px">GET /api/v1/health · /api/v1/regions · /api/v1/safety-hubs · /api/v1/reports<br>POST /api/v1/routes/compare · /api/v1/register · /api/v1/login · /api/v1/admin/login<br>Lihat API.md untuk daftar lengkap.</p><p style="font-size:13px">Admin demo: admin@titikaman.id / Admin123!</p></div></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
let token=localStorage.getItem('ta_token')||''; const out=document.getElementById('out');
function show(x){ out.textContent=typeof x==='string'?x:JSON.stringify(x,null,2); }
async function api(path,opt={}){ const r=await fetch('/api/v1'+path,{headers:{'Accept':'application/json','Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...opt}); const j=await r.json().catch(()=>({})); show({http:r.status,...j}); return {r,j}; }
const map=L.map('map').setView([-6.1928,106.89763],15);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
let layers=L.layerGroup().addTo(map), fastLine, safeLine;
const centers={rawamangun:[-6.1928,106.89763],'unesa-lidah-wetan':[-7.30071,112.67289],'unesa-ketintang':[-7.31143,112.72937]};
document.getElementById('region').addEventListener('change',e=>{map.setView(centers[e.target.value],15); loadData();});
async function loadData(){ const reg=document.getElementById('region').value; const {j}=await api('/safety-hubs?region_slug='+reg); const {j:j2}=await api('/reports?region_slug='+reg); layers.clearLayers();
 (j.data||[]).forEach(h=>L.circleMarker([h.lat,h.lng],{color:'#3b82f6',radius:8}).bindPopup('<b>'+h.name+'</b><br>'+h.type+' · '+(h.address||'')).addTo(layers));
 (j2.data||[]).forEach(p=>L.circleMarker([p.lat,p.lng],{color:p.color==='yellow'?'#eab308':'#f97316',radius:7}).bindPopup('<b>'+p.label+'</b><br>'+p.status+' · upvote '+p.upvotes_count).addTo(layers));
 const s=await api('/simulation'); document.getElementById('sim').textContent=String(s.j?.data?.simulation_mode); }
function line(coords,color,dash){ return L.polyline(coords.map(c=>[c[1],c[0]]),{color,weight:color==='#22c55e'?6:4,dashArray:dash||null}).addTo(map); }
async function loadRoutes(){ const [olat,olng]=document.getElementById('o').value.split(',').map(Number); const [dlat,dlng]=document.getElementById('d').value.split(',').map(Number);
 const {j}=await api('/routes/compare',{method:'POST',body:JSON.stringify({origin_lat:olat,origin_lng:olng,destination_lat:dlat,destination_lng:dlng,mode:document.getElementById('mode').value,region_slug:document.getElementById('region').value})});
 if(!j.data) return; if(fastLine)map.removeLayer(fastLine); if(safeLine)map.removeLayer(safeLine);
 fastLine=line(j.data.fastest.geometry.coordinates,'#eab308','6 6'); safeLine=line(j.data.safepass.geometry.coordinates,'#22c55e');
 document.getElementById('routeInfo').innerHTML='Sumber: <b>'+j.data.source+'</b> · Tercepat: '+Math.round(j.data.fastest.duration/60)+' mnt · SafePass: '+Math.round(j.data.safepass.duration/60)+' mnt · Dihindari: '+(j.data.safepass.avoided_reports||[]).length+' laporan · Hub dilewati: '+(j.data.safepass.hubs_passed||[]).length+'<br><span style="color:#fbbf24">'+j.data.disclaimer+'</span>';
 map.fitBounds(safeLine.getBounds()); }
async function login(){ const {j}=await api('/login',{method:'POST',body:JSON.stringify({email:document.getElementById('email').value,password:document.getElementById('pass').value})}); if(j.data?.token){token=j.data.token; localStorage.setItem('ta_token',token); document.getElementById('who').textContent='Login sebagai '+j.data.user.name+' ('+j.data.user.role+')';} }
async function lapor(){ const [lat,lng]=document.getElementById('rloc').value.split(',').map(Number); const [ulat,ulng]=document.getElementById('uloc').value.split(',').map(Number);
 await api('/reports',{method:'POST',body:JSON.stringify({region_slug:document.getElementById('region').value,category:document.getElementById('cat').value,lat,lng,user_lat:ulat,user_lng:ulng,description:document.getElementById('desc').value})}); loadData(); }
async function sos(){ const {j}=await api('/sos',{method:'POST',body:JSON.stringify({region_slug:document.getElementById('region').value,message:'SOS tes dari halaman test'})}); if(j.success) window.location.href='tel:110'; }
loadData();
</script></body></html>
<?php /**PATH /home/hatch/workspace/titikaman-backend/resources/views/test.blade.php ENDPATH**/ ?>